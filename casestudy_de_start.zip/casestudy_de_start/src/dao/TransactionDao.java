//Rebecca Amarh-Adjei
//Data Engineering Class
//Case Study- September 2018
package dao;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import model.Transaction;
import resources.MyQuries;

public class TransactionDao extends dbconnection_abstract {
 

	public ArrayList<Transaction> getTransbyZipMonYr(String CustZip,int month, int year) throws SQLException, 
    InstantiationException, IllegalAccessException, ClassNotFoundException, IOException {
	
	   ArrayList<Transaction> transactions = new ArrayList<Transaction>();

try{
	 myconnection();
	 System.out.println("");
	 System.out.println("Connected to Database.");
	 System.out.println("");
}

catch (Exception e) {
   e.getStackTrace();

}
	 ps = con.prepareStatement(MyQuries.transByZipMonYr);
		ps.setString(1,CustZip);
		ps.setInt(2,month);
		ps.setInt(3,year);
		rs = ps.executeQuery();
		
		
		while(rs.next()) {
			Transaction t1 = new Transaction();
			t1.setTransID(rs.getInt(1));
			t1.setDay(rs.getInt(2));
			t1.setMonth(rs.getInt(3));
			t1.setYear(rs.getInt(4));
			t1.setCardNo(rs.getString(5));
			t1.setSsn(rs.getInt(6));
			t1.setBranchCode(rs.getInt(7));
			t1.setType(rs.getString(8));
			t1.setValue(rs.getDouble(9));
			//Save  all transactions made by customers living in a given Zip Code, Month and Year to Array
			transactions.add(t1);
		}		
		return transactions;
}


public Transaction gettotalbyType(String type) throws SQLException, InstantiationException, IllegalAccessException, 
ClassNotFoundException, IOException
{
	myconnection();
	ps = con.prepareStatement(MyQuries.totaByType);
	ps.setString(1, type);
	rs = ps.executeQuery();
	Transaction t2 = new Transaction();
	
	if(rs.next())
	{
	   
		t2.setValue(rs.getDouble(1));
		t2.setCount(rs.getInt(2));
		
		//System.out.println(" Sum of values of all Transaction " + number);
		//System.out.println("Total Number of Transaction: "+ transaction_type);
		return t2;  }		return null;
}


public ArrayList<Transaction> getNumSumTransBrSt(String branchState) throws SQLException, 
InstantiationException, IllegalAccessException, ClassNotFoundException, IOException {
	
	ArrayList<Transaction> transByState = new ArrayList<Transaction>();

	try{
		myconnection();
		System.out.println("");
		System.out.println("Connected to Database.");
		System.out.println("");
	}

	catch (Exception e) {
	 e.getStackTrace();

	}
	
	ps = con.prepareStatement(MyQuries.numSumTransBrSt);
	ps.setString(1,branchState);
	rs = ps.executeQuery();	

	while(rs.next()) {
		Transaction t3 = new Transaction();

		t3.setBranchCode(rs.getInt(1));
		t3.setBranchName(rs.getString(2));
		t3.setBranchState(rs.getString(3));
		t3.setTransID(rs.getInt(4));
		t3.setValue(rs.getDouble(5));
	 
	 //Save  count of transaction and sum of transaction by Branches in a State
		transByState.add(t3);
	}		
	return transByState;
}


}

//Rebecca Amarh-Adjei
//Data Engineering Class
//Case Study- September 2018
package runner;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import dao.TransactionDao;
import dao.dbconnection_abstract;
import model.Transaction;


public class Tranaction_runnable extends dbconnection_abstract{
			
		
		public void getTransbyZipMonYr() throws InstantiationException, IllegalAccessException, ClassNotFoundException, 
		IOException, SQLException
		{
				
			myconnection();
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Please enter the Zip code:");
			String CustZip = sc.nextLine();
			
			System.out.println("Please enter the Month:");
			int month = sc.nextInt();
			
			System.out.println("Please enter the Year:");
			int year= sc.nextInt();	
			
			TransactionDao one = new TransactionDao();
			ArrayList<Transaction> oneTransaction = one.getTransbyZipMonYr(CustZip,month,year);
			
			
			
			
			//  out put for query. 
			Transaction t1;
			if( oneTransaction.size() == 0) {
				System.out.println("Output Null");
				System.out.println("");
			}
				else {
				System.out.println("Trasaction made by customers in a given zipcode for a given month and year.");
				System.out.printf("%-8s|%-4s|%-6s|%-6s|%-18s|%-11s|%-7s|%-15s|%-12s\n","TRANSID","DAY","MONTH","YEAR",
				"CARD NO","SS NO","BRANCH","TRANS TYPE","TRANS VALUE");
				}
		
			for (int i=0; i < oneTransaction.size(); i++) {
				t1 = oneTransaction.get(i);
				System.out.printf("%-8s|%-4s|%-6s|%-6s|%-18s|%-11s|%-7s|%-15s|%-12s\n" , t1.getTransID() , t1.getDay() 
				,t1.getMonth() , t1.getYear() ,t1.getCardNo() , t1.getSsn() , t1.getBranchCode() ,t1.getType() 
				,t1.getValue());
				
			}
			
		}
		
		public void getTotalByType() throws InstantiationException, IllegalAccessException, ClassNotFoundException, 
		IOException, SQLException
		{
				
			myconnection();
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			System.out.println("");
			System.out.println("Please enter transaction Type:");
			
			String type = sc.nextLine();
			
			TransactionDao td = new TransactionDao();
			Transaction mytransaction = td.gettotalbyType(type);
			
			if (mytransaction == null) {
			System.out.println("Transaction tpye is " + mytransaction +".");
			System.out.println("");
			}
			else  {
		    System.out.println("Trasaction Type count and Trasaction Value");
			System.out.printf("%-18s|%-18s\n", "Trasaction Count", "Transaction Value");
			System.out.printf("%-18s|%-18s\n",mytransaction.getCount(), mytransaction.getValue());
			}
		}
		
		public void getNumSumTransBrSt() throws InstantiationException, IllegalAccessException, ClassNotFoundException, 
		IOException, SQLException
		{
				
			myconnection();
			@SuppressWarnings("resource")
			Scanner sc = new Scanner(System.in);
			
			System.out.println("");
			System.out.println("Please enter the State for which you want the "
					+ "total number and value of transactions for branches.");
			String branchState = sc.nextLine();
			
			
			TransactionDao three = new TransactionDao();
			ArrayList<Transaction> threeTransaction = three.getNumSumTransBrSt(branchState);
			
					
			//  out put for query. 
			Transaction t3;
			if( threeTransaction.size() == 0) {
				System.out.println("Output Null");
				System.out.println("");
			}
				else {
				System.out.println("The Number and total values of transactions for Branches in the state " + branchState + " .");
				System.out.printf("%-8s|%-14s|%-10s|%-10s|%-21s\n","BR-CODE","BR-NAME","BR-STATE","NO.TRANS",
				"TOTAL VALUE");
				}
		
			for (int i=0; i < threeTransaction.size(); i++) {
				t3 = threeTransaction.get(i);
				System.out.printf("%-8s|%-14s|%-10s|%-10s|%-21s\n", t3.getBranchCode(), t3.getBranchName() , t3.getBranchState() ,
				t3.getTransID() ,t3.getValue());
				
			}
		}	
}
			
			
			
		

//Rebecca Amarh-Adjei
//Data Engineering Class
//Case Study- September 2018
package runner;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

import exceptions.NoZeroException;

public class Main  {

	public static void main(String[] args) throws InstantiationException, IllegalAccessException, 
	ClassNotFoundException, IOException, SQLException {
		// TODO Auto-generated method stub
		
try {
	throw new NoZeroException("my custom exception");
	}catch (NoZeroException e) {
	//	e.printStackTrace();
		System.out.println(e.getMessage());
	}
		
		char letter;      // The user's Y or N decision

	       
	       
	       // Create a scanner object to read from the keyboard

		@SuppressWarnings("resource")
		Scanner keyboard = new Scanner(System.in);
	      
		// The do loop allows the menu to be displayed first
	       
		do
	         { 
	          // TASK #1 Call the printMenu method
	          
			printMenu();
	          
	          int select = keyboard.nextInt();
	
	         
	          switch(select)
	          {
	          
	             case 1:
	              
	                // 2.1.1 (#1) invokes runnable 
         		    Tranaction_runnable t1 = new Tranaction_runnable();
         		    t1.getTransbyZipMonYr();  
	
	                break;
	             
	             case 2:
	                 
	                // 2.1.1 (#2) invokes runnable
         		    Tranaction_runnable t2 = new Tranaction_runnable();
	       		    t2.getTotalByType();
	
	                break;
	   
	 
	             case 3:
	            	// 2.1.1 (#3) invokes runnable
	         		Tranaction_runnable t3 = new Tranaction_runnable();
         		    t3.getNumSumTransBrSt(); 
	
	                break;
	                
	                
	             case 4:
	            	 
	            	//2.1.2 (#1)
         		   Customer_runnable c1 = new Customer_runnable();
           		   c1.getckCustAcctDtl();
	                
	               break;
	                
	             case 5:
	            	 
	            	//2.1.2 (#2)
	         		Customer_runnable c2 = new Customer_runnable();
	         		c2.getupdateCustDtl();	
	                
	                break;

	             case 6:
	            	//2.1.2 (#3)
	            	Customer_runnable c3 = new Customer_runnable();
	            	c3.MonthlyBill();	
	                
	                break;

	             case 7:
	            	 
	            	//2.1.2 (#4)
	         		Customer_runnable c4 = new Customer_runnable();
	         		c4.getcustTransBtwn();
	                
	                break;


	             default:
	            	 
	                System.out.println("You did not enter a valid selection.");
	          }
	          keyboard.nextLine(); // Consume the new line
	          System.out.println();
	          System.out.println("Do you want to exit the program (y/n)?: ");
	          
	          String answer = keyboard.nextLine();
	           letter = answer.charAt(0);
	       } while(letter != 'Y' && letter != 'y');
		System.out.println("GOOD BYE, AU REVOIR, Auf Wiedersehen, HASTA LA Vista BABY !");
	    }
	   
	 // TASK #1 Create the printMenu method here
	    //This method prints out the menu of options for the user to select from 
	    
	    public static void printMenu(){
	        System.out.println("This is Transaction and Customer details Module.");
	        System.out.println("Select the Detail Module you would like to use.");
	        System.out.println("1. Display transaction for a given Zip Code and a given month and year.");
	        System.out.println("2. Display the number and sum of transactions for a given type. ");
	        System.out.println("3. Display the number and total values of transaction of Branches for a given State.");
     System.out.println("4. Check the account details of a customer.");	
		System.out.println("5. Modify the account details of a customer.");  
	    System.out.println("6. Generate a monthly bill for a credit card number for a given month and year."); 
 System.out.println("7. Display a customers transactions between two dates." +"\n");
	        System.out.println("Enter the number of your selection:");

	
	}
	

}

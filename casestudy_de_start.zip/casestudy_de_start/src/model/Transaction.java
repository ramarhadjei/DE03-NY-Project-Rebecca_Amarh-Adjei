//Rebecca Amarh-Adjei
//Data Engineering Class
//Case Study- September 2018
package model;

public class Transaction{
	
	protected int day, month, year, ssn, branchCode, count, transID ;
	protected Double Value;
	protected String branchState, CustZip,branchName, cardNo, type;
	
	
	
	public String getBranchState() {
		return branchState;
	}

	public void setBranchState(String branchState) {
		this.branchState = branchState;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	public String getCustZip() {
		return CustZip;
	}

	public void setCustZip(String custZip) {
		CustZip = custZip;
	}

	public int getTransID() {
		return transID;
	}

	public void setTransID(int transID) {
		this.transID = transID;
	}

	
	    public Double getValue() {
		return Value;
	}

	public void setValue(Double value) {
		Value = value;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getSsn() {
		return ssn;
	}

	public void setSsn(int ssn) {
		this.ssn = ssn;
	}

	public int getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(int branchCode) {
		this.branchCode = branchCode;
	}

	public int getCount() {
		return count;
	}

	public String getCardNo() {
		return cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setDay(int day) {
	this.day = day;
	}

	public int getDay()
	{
	return day;
	}

	public void setCount(int count) {
	// TODO Auto-generated method stub
	this.count  =      count;
	}

}

//Rebecca Amarh-Adjei
//Data Engineering Class
//Case Study- September 2018
package exceptions;

import java.util.Scanner;

public class MainException {

public static void main(String[] args) {
		
		@SuppressWarnings("resource")
		Scanner input = new Scanner (System.in);
		System.out.println("Please enter positive interger excluding zero.");
		int myInt = input.nextInt();
		
		if (myInt==0) {
			try {
				throw new NoZeroException("Zero is invalid!!!!");
			}
			catch (NoZeroException e) {
				e.printStackTrace();
			}
		}

	}

}



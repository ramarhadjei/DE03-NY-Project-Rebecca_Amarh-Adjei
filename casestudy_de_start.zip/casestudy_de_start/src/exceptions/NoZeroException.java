//Rebecca Amarh-Adjei
//Data Engineering Class
//Case Study- September 2018
package exceptions;

public class NoZeroException extends Exception{
	public NoZeroException (String msg) {
		super(msg);
	}
	

}
